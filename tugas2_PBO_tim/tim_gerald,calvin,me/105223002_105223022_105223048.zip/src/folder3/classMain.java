package folder3;
import folder1.C1;
import folder2.C2;

public class classMain {
    public static void main(String[] args) {
        C1 CD = new C1();
        CD.pesanCD();

        C2 CP = new C2();
        CP.PesanCP();
    }
}

