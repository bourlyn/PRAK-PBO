package folder2;

public class C2 {
    private String pesan ="folder ini khusus orang dalam";

    public void PesanCP() {
        System.out.println(pesan);
        }
    }

