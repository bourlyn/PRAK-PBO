package folder1;

public class C1 {
    public void pesanCD() {
        System.out.println("ini folder bawaan");
    } 
}
