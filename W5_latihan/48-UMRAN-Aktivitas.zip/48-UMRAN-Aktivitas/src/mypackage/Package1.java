package mypackage;

public class Package1 {
    public static void sayHello(){
        System.out.println("halo saya Zack");
    }    
}
