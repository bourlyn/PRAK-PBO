package kelola;
import model.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class KelolaLaporan {
    private List<Laporan> laporanList;
    private KelolaBarang kelolaBarang;
    private Scanner scanner;

    public KelolaLaporan(KelolaBarang kelolaBarang) {
    this.laporanList = new ArrayList<>();
    this.kelolaBarang = kelolaBarang;
    this.scanner = new Scanner(System.in);
    }

    public void inputLaporan() {
    System.out.println("\n=== INPUT LAPORAN BARANG ===");
    kelolaBarang.lihat();
    System.out.print("Masukkan ID Barang: ");
    int idBarang = scanner.nextInt();
    scanner.nextLine();

    Barang barang = kelolaBarang.cariBarang(idBarang);
    if (barang == null) {
        System.out.println("Barang tidak ditemukan!");
        return;
     }

    System.out.print("Keterangan Kerusakan: ");
    String keterangan = scanner.nextLine();
    System.out.print("Nama Pelapor: ");
    String pelapor = scanner.nextLine();

    Laporan laporan = new Laporan(barang, keterangan, pelapor);
    laporanList.add(laporan);
    barang.setTersedia(false);
    System.out.println("Laporan berhasil dibuat:\n" + laporan);
    }
}
