package kelola;

public interface Kelola {
    void tambah();
    void lihat();
    void edit();
    void hapus();
}