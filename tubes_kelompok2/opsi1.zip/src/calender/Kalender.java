package calender;

public class Kalender {
    public static boolean isValidTanggal(int tanggal) {
        return tanggal >= 1 && tanggal <= 30;
    }
}