package inventory;

public class PermintaanPinjam {
    public String nimPeminjam;
    public int idBarang;
    public boolean disetujui;
    public int tanggalPinjam;

    public PermintaanPinjam(String nimPeminjam, int idBarang, int tanggalPinjam) {
        this.nimPeminjam = nimPeminjam;
        this.idBarang = idBarang;
        this.tanggalPinjam = tanggalPinjam;
        this.disetujui = false;
    }
}