package inventory;

public class Pengguna {
    public String nim;
    public String nama;

    public Pengguna(String nim, String nama) {
        this.nim = nim;
        this.nama = nama;
    }
}