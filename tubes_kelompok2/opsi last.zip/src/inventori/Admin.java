package inventori;

public class Admin extends Pengguna {
    public Admin(String nim, String nama) {
        super(nim, nama);
    }

    @Override
    public String getRole() {
        return "Admin";
    }
}