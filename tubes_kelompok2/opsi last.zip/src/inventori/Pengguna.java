package inventori;

public abstract class Pengguna {
    private String nim;
    private String nama;

    public Pengguna(String nim, String nama) {
        this.nim = nim;
        this.nama = nama;
    }

    public abstract String getRole();

    public String getNim() {
        return nim;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
}