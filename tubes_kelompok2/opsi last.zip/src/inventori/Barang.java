package inventori;

public class Barang {
    private int id;
    private String nama;
    private boolean tersedia;
    private String peminjam;
    private int tanggalPinjam;
    private String kondisi;

    public Barang(int id, String nama) {
        this.id = id;
        this.nama = nama;
        this.tersedia = true;
        this.peminjam = "";
        this.tanggalPinjam = 0;
        this.kondisi = "baik";
    }

    public int getId() {
        return id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public boolean isTersedia() {
        return tersedia;
    }

    public void setTersedia(boolean tersedia) {
        this.tersedia = tersedia;
    }

    public String getPeminjam() {
        return peminjam;
    }

    public void setPeminjam(String peminjam) {
        this.peminjam = peminjam;
    }

    public int getTanggalPinjam() {
        return tanggalPinjam;
    }

    public void setTanggalPinjam(int tanggalPinjam) {
        this.tanggalPinjam = tanggalPinjam;
    }

    public String getKondisi() {
        return kondisi;
    }

    public void setKondisi(String kondisi) {
        this.kondisi = kondisi;
    }
}