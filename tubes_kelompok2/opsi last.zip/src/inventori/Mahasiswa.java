package inventori;

public class Mahasiswa extends Pengguna {
    public Mahasiswa(String nim, String nama) {
        super(nim, nama);
    }

    @Override
    public String getRole() {
        return "Mahasiswa";
    }
}