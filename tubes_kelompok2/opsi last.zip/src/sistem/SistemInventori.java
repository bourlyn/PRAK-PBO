package sistem;

import inventori.*;
import java.util.ArrayList;
import java.util.Scanner;

public class SistemInventori {
    private ArrayList<Admin> daftarAdmin = new ArrayList<>();
    private ArrayList<Mahasiswa> daftarMahasiswa = new ArrayList<>();
    private ArrayList<Barang> daftarBarang = new ArrayList<>();
    private ArrayList<Peminjaman> daftarPeminjaman = new ArrayList<>();
    private Scanner input = new Scanner(System.in);

    public SistemInventori() {
        daftarAdmin.add(new Admin("0", "rendy"));
        daftarAdmin.add(new Admin("002", "Admin Kedua"));
    }

    public boolean loginAdmin(String nim, String nama) {
        for (Admin admin : daftarAdmin) {
            if (admin.getNim().equals(nim) && admin.getNama().equals(nama)) {
                return true;
            }
        }
        return false;
    }

    public void kelolaPengguna() {
        System.out.println("\n=== KELOLA PENGGUNA ===");
        System.out.println("1. Tambah Pengguna");
        System.out.println("2. Lihat Pengguna");
        System.out.println("3. Update Pengguna");
        System.out.println("4. Hapus Pengguna");
        System.out.print("Pilih menu: ");
        
        int pilihan = input.nextInt();
        input.nextLine();
        
        switch (pilihan) {
            case 1:
                System.out.print("Masukkan NIM: ");
                String nim = input.nextLine();
                System.out.print("Masukkan Nama: ");
                String nama = input.nextLine();
                daftarMahasiswa.add(new Mahasiswa(nim, nama));
                System.out.println("Pengguna berhasil ditambahkan!");
                break;
            case 2:
                System.out.println("\nDaftar Pengguna:");
                for (Mahasiswa m : daftarMahasiswa) {
                    System.out.println(m.getNim() + " - " + m.getNama());
                }
                break;
            case 3:
                System.out.print("Masukkan NIM yang akan diupdate: ");
                String nimUpdate = input.nextLine();
                System.out.print("Masukkan Nama baru: ");
                String namaBaru = input.nextLine();
                for (Mahasiswa m : daftarMahasiswa) {
                    if (m.getNim().equals(nimUpdate)) {
                        m.setNama(namaBaru);
                        System.out.println("Data pengguna berhasil diupdate!");
                        return;
                    }
                }
                System.out.println("Pengguna tidak ditemukan!");
                break;
            case 4:
                System.out.print("Masukkan NIM yang akan dihapus: ");
                String nimHapus = input.nextLine();
                if (daftarMahasiswa.removeIf(m -> m.getNim().equals(nimHapus))) {
                    System.out.println("Pengguna berhasil dihapus!");
                } else {
                    System.out.println("Pengguna tidak ditemukan!");
                }
                break;
            default:
                System.out.println("Pilihan tidak valid!");
        }
    }

    public void kelolaBarang() {
        System.out.println("\n=== KELOLA BARANG ===");
        System.out.println("1. Tambah Barang");
        System.out.println("2. Lihat Barang");
        System.out.println("3. Update Barang");
        System.out.println("4. Hapus Barang");
        System.out.print("Pilih menu: ");
        
        int pilihan = input.nextInt();
        input.nextLine();
        
        switch (pilihan) {
            case 1:
                System.out.print("Masukkan ID Barang: ");
                int id = input.nextInt();
                input.nextLine();
                System.out.print("Masukkan Nama Barang: ");
                String nama = input.nextLine();
                daftarBarang.add(new Barang(id, nama));
                System.out.println("Barang berhasil ditambahkan!");
                break;
            case 2:
                System.out.println("\nDaftar Barang:");
                for (Barang b : daftarBarang) {
                    String status = b.isTersedia() ? "Tersedia" : "Dipinjam oleh " + b.getPeminjam();
                    System.out.println(b.getId() + " - " + b.getNama() + " [" + status + ", Kondisi: " + b.getKondisi() + "]");
                }
                break;
            case 3:
                System.out.print("Masukkan ID Barang yang akan diupdate: ");
                int idUpdate = input.nextInt();
                input.nextLine();
                System.out.print("Masukkan Nama baru: ");
                String namaBaru = input.nextLine();
                for (Barang b : daftarBarang) {
                    if (b.getId() == idUpdate) {
                        b.setNama(namaBaru);
                        System.out.println("Data barang berhasil diupdate!");
                        return;
                    }
                }
                System.out.println("Barang tidak ditemukan!");
                break;
            case 4:
                System.out.print("Masukkan ID Barang yang akan dihapus: ");
                int idHapus = input.nextInt();
                input.nextLine();
                if (daftarBarang.removeIf(b -> b.getId() == idHapus)) {
                    System.out.println("Barang berhasil dihapus!");
                } else {
                    System.out.println("Barang tidak ditemukan!");
                }
                break;
            default:
                System.out.println("Pilihan tidak valid!");
        }
    }

    public void menuPeminjaman() {
        System.out.println("\n=== MENU PEMINJAMAN ===");
        System.out.println("1. Ajukan Peminjaman");
        System.out.println("2. Setujui Peminjaman");
        System.out.print("Pilih menu: ");
        
        int pilihan = input.nextInt();
        input.nextLine();
        
        switch (pilihan) {
            case 1:
                System.out.print("Masukkan NIM Peminjam: ");
                String nim = input.nextLine();
                
                boolean mahasiswaAda = false;
                for (Mahasiswa m : daftarMahasiswa) {
                    if (m.getNim().equals(nim)) {
                        mahasiswaAda = true;
                        break;
                    }
                }
                
                if (!mahasiswaAda) {
                    System.out.println("NIM tidak terdaftar! Silakan daftarkan pengguna terlebih dahulu.");
                    return;
                }
                
                System.out.println("\nDaftar Barang Tersedia:");
                for (Barang b : daftarBarang) {
                    if (b.isTersedia()) {
                        System.out.println("ID: " + b.getId() + " - " + b.getNama() + " (Kondisi: " + b.getKondisi() + ")");
                    }
                }
                
                System.out.print("Masukkan ID Barang yang ingin dipinjam: ");
                int idBarang = input.nextInt();
                System.out.print("Masukkan Tanggal Pinjam (1-30): ");
                int tanggal = input.nextInt();
                input.nextLine();
                
                if (tanggal < 1 || tanggal > 30) {
                    System.out.println("Tanggal tidak valid!");
                    return;
                }
                
                for (Barang barang : daftarBarang) {
                    if (barang.getId() == idBarang) {
                        if (!barang.isTersedia()) {
                            System.out.println("Barang sedang dipinjam!");
                            return;
                        }
                        daftarPeminjaman.add(new Peminjaman(nim, idBarang, tanggal));
                        System.out.println("Permintaan peminjaman berhasil diajukan!");
                        return;
                    }
                }
                System.out.println("Barang tidak ditemukan!");
                break;
            case 2:
                if (daftarPeminjaman.isEmpty()) {
                    System.out.println("Tidak ada permintaan peminjaman!");
                    return;
                }
                
                System.out.println("\nDaftar Permintaan Peminjaman:");
                for (Peminjaman p : daftarPeminjaman) {
                    if (!p.isDisetujui()) {
                        System.out.println("NIM: " + p.getNimPeminjam() + ", Barang ID: " + p.getIdBarang() + ", Tanggal: " + p.getTanggalPinjam());
                    }
                }

                System.out.print("Masukkan NIM Peminjam: ");
                String nimPeminjam = input.nextLine();
                System.out.print("Masukkan ID Barang: ");
                int idBarangSetuju = input.nextInt();
                input.nextLine();

                for (Peminjaman p : daftarPeminjaman) {
                    if (p.getNimPeminjam().equals(nimPeminjam) && p.getIdBarang() == idBarangSetuju && !p.isDisetujui()) {
                        p.setDisetujui(true);
                        for (Barang b : daftarBarang) {
                            if (b.getId() == p.getIdBarang()) {
                                b.setTersedia(false);
                                b.setPeminjam(p.getNimPeminjam());
                                b.setTanggalPinjam(p.getTanggalPinjam());
                                break;
                            }
                        }
                        System.out.println("Permintaan peminjaman disetujui!");
                        return;
                    }
                }
                System.out.println("Permintaan peminjaman tidak ditemukan!");
                break;
            default:
                System.out.println("Menu tidak valid!");
        }
    }

    public void menuPengembalian() {
        System.out.println("\n=== PENGEMBALIAN BARANG ===");
        System.out.print("Masukkan NIM Peminjam: ");
        String nim = input.nextLine();
        System.out.print("Masukkan ID Barang: ");
        int id = input.nextInt();
        System.out.print("Masukkan Tanggal Kembali (1-30): ");
        int tglKembali = input.nextInt();
        input.nextLine();
        
        if (tglKembali < 1 || tglKembali > 30) {
            System.out.println("Tanggal tidak valid!");
            return;
        }

        for (Barang b : daftarBarang) {
            if (b.getId() == id && b.getPeminjam().equals(nim)) {
                b.setTersedia(true);
                b.setPeminjam("");
                
                int selisih = 0;
                if (tglKembali >= b.getTanggalPinjam()) {
                    selisih = tglKembali - b.getTanggalPinjam();
                } else {
                    selisih = (30 - b.getTanggalPinjam()) + tglKembali;
                }
                
                if (selisih > 7) {
                    System.out.println("Keterlambatan: " + (selisih-7) + " hari");
                } else {
                    System.out.println("Barang berhasil dikembalikan tepat waktu!");
                }
                return;
            }
        }
        System.out.println("Data tidak valid!");
    }

    public void menuLaporan() {
        System.out.println("\n=== MENU LAPORAN ===");
        System.out.println("1. Lihat Barang Tersedia");
        System.out.println("2. Lihat Barang Dipinjam");
        System.out.println("3. Laporkan Kondisi Barang");
        System.out.print("Pilih menu: ");
        
        int pilihan = input.nextInt();
        input.nextLine();
        
        switch (pilihan) {
            case 1:
                System.out.println("\nDaftar Barang Tersedia:");
                for (Barang b : daftarBarang) {
                    if (b.isTersedia()) {
                        System.out.println("ID: " + b.getId() + " - " + b.getNama() + " (Kondisi: " + b.getKondisi() + ")");
                    }
                }
                break;
            case 2:
                System.out.println("\nDaftar Barang Dipinjam:");
                for (Barang b : daftarBarang) {
                    if (!b.isTersedia()) {
                        System.out.println("ID: " + b.getId() + " - " + b.getNama() + " (Dipinjam oleh: " + b.getPeminjam() + ")");
                    }
                }
                break;
            case 3:
                System.out.println("\n=== LAPORKAN KONDISI BARANG ===");
                System.out.println("\nDaftar Barang:");
                for (Barang b : daftarBarang) {
                    String status = b.isTersedia() ? "Tersedia" : "Dipinjam oleh " + b.getPeminjam();
                    System.out.println(b.getId() + " - " + b.getNama() + " [" + status + ", Kondisi: " + b.getKondisi() + "]");
                }
                System.out.print("Masukkan ID Barang: ");
                int id = input.nextInt();
                input.nextLine();
                
                for (Barang b : daftarBarang) {
                    if (b.getId() == id) {
                        System.out.println("\nPilih kondisi barang:");
                        System.out.println("1. Baik");
                        System.out.println("2. Rusak Ringan");
                        System.out.println("3. Rusak Berat");
                        System.out.print("Pilih kondisi (1-3): ");
                        
                        int kondisi = input.nextInt();
                        input.nextLine();
                        
                        if (kondisi == 1) {
                            b.setKondisi("baik");
                        } else if (kondisi == 2) {
                            b.setKondisi("rusak ringan");
                        } else if (kondisi == 3) {
                            b.setKondisi("rusak berat");
                        } else {
                            System.out.println("Pilihan tidak valid!");
                            return;
                        }
                        
                        System.out.println("Kondisi barang " + b.getNama() + " berhasil diperbarui!");
                        System.out.println("Kondisi terbaru: " + b.getKondisi());
                        return;
                    }
                }
                System.out.println("Barang tidak ditemukan!");
                break;
            default:
                System.out.println("Menu tidak valid!");
        }
    }
}