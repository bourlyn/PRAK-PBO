package inventori.kelola;

import inventori.models.*;
import inventori.database.PenggunaDB;
import java.util.*;

public class KelolaPengguna {
    private List<Pengguna> penggunaList;
    private Scanner scanner = new Scanner(System.in);

    public KelolaPengguna() {
        penggunaList = PenggunaDB.load();
    }

    public void menu() {
        while (true) {
            System.out.println("\n=== KELOLA PENGGUNA ===");
            System.out.println("1. Tambah Pengguna");
            System.out.println("2. Lihat Pengguna");
            System.out.println("3. Edit Pengguna");
            System.out.println("4. Hapus Pengguna");
            System.out.println("0. Kembali");
            System.out.print("Pilih: ");
            int pilih = Validator.validateInt(scanner);

            switch (pilih) {
                case 1 -> tambahPengguna();
                case 2 -> lihatPengguna();
                case 3 -> editPengguna();
                case 4 -> hapusPengguna();
                case 0 -> { return; }
                default -> System.out.println("Pilihan tidak valid!");
            }
        }
    }

    private void tambahPengguna() {
        System.out.println("\n=== TAMBAH PENGGUNA ===");
        String id = Validator.validateString(scanner, "Masukkan NIM/ID: ");
        String nama = Validator.validateString(scanner, "Masukkan Nama: ");
        System.out.print("Sebagai (1=Mahasiswa, 2=Admin): ");
        int jenis = Validator.validateInt(scanner);

        if (jenis == 1) {
            penggunaList.add(new Mahasiswa(id, nama));
        } else if (jenis == 2) {
            penggunaList.add(new Admin(id, nama));
        } else {
            System.out.println("Tipe tidak valid!");
            return;
        }

        PenggunaDB.save(penggunaList);
        System.out.println("Pengguna berhasil ditambahkan.");
    }

    private void lihatPengguna() {
        System.out.println("\n=== DAFTAR PENGGUNA ===");
        for (Pengguna p : penggunaList) {
            System.out.println(p);
        }
    }

    private void editPengguna() {
        System.out.println("\n=== EDIT PENGGUNA ===");
        String id = Validator.validateString(scanner, "Masukkan ID/NIM yang ingin diubah: ");
        for (Pengguna p : penggunaList) {
            if (p.getId().equals(id)) {
                String namaBaru = Validator.validateString(scanner, "Masukkan nama baru: ");
                p.setNama(namaBaru);
                PenggunaDB.save(penggunaList);
                System.out.println("Pengguna berhasil diperbarui.");
                return;
            }
        }
        System.out.println("Pengguna tidak ditemukan.");
    }

    private void hapusPengguna() {
        System.out.println("\n=== HAPUS PENGGUNA ===");
        String id = Validator.validateString(scanner, "Masukkan ID/NIM yang ingin dihapus: ");
        Pengguna target = null;
        for (Pengguna p : penggunaList) {
            if (p.getId().equals(id)) {
                target = p;
                break;
            }
        }

        if (target != null) {
            penggunaList.remove(target);
            PenggunaDB.save(penggunaList);
            System.out.println("Pengguna berhasil dihapus.");
        } else {
            System.out.println("Pengguna tidak ditemukan.");
        }
    }

    public boolean loginAdmin(String id, String nama) {
        for (Pengguna p : penggunaList) {
            if (p instanceof Admin && p.getId().equals(id) && p.getNama().equals(nama)) {
                return true;
            }
        }
        return false;
    }

    public List<Pengguna> getPenggunaList() {
        return penggunaList;
    }
}
