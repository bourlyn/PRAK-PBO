package inventori.kelola;

import inventori.models.*;
import java.util.*;

public class KelolaPeminjaman {
    private List<Peminjaman> pinjamanList = new ArrayList<>();
    private KelolaPengguna kelolaPengguna;
    private KelolaBarang kelolaBarang;
    private Scanner scanner = new Scanner(System.in);

    public KelolaPeminjaman(KelolaPengguna pengguna, KelolaBarang barang) {
        this.kelolaPengguna = pengguna;
        this.kelolaBarang = barang;
    }

    public void menu() {
        while (true) {
            System.out.println("\n=== KELOLA PEMINJAMAN ===");
            System.out.println("1. Ajukan Peminjaman");
            System.out.println("2. Terima Peminjaman");
            System.out.println("3. Pengembalian");
            System.out.println("4. Lihat Semua Peminjaman");
            System.out.println("0. Kembali");
            System.out.print("Pilih: ");

            int pilih = Validator.validateInt(scanner);
            switch (pilih) {
                case 1 -> ajukanPeminjaman();
                case 2 -> terimaPeminjaman();
                case 3 -> pengembalian();
                case 4 -> lihatPeminjaman();
                case 0 -> { return; }
                default -> System.out.println("Pilihan tidak valid!");
            }
        }
    }

    private void ajukanPeminjaman() {
        System.out.println("\n=== AJUKAN PEMINJAMAN ===");
        String id = Validator.validateString(scanner, "ID Mahasiswa: ");
        String nama = Validator.validateString(scanner, "Nama Mahasiswa: ");
        Barang barang = kelolaBarang.pilihBarang();

        if (barang == null || !barang.isTersedia()) {
            System.out.println("Barang tidak tersedia!");
            return;
        }

        int tglPinjam = Validator.validateInt(scanner, "Tanggal Pinjam (1-30): ");
        pinjamanList.add(new Peminjaman(new Mahasiswa(id, nama), barang, tglPinjam));
        System.out.println("Peminjaman diajukan. Menunggu konfirmasi.");
    }

    private void terimaPeminjaman() {
        System.out.println("\n=== TERIMA PEMINJAMAN ===");
        int index = 1;
        for (Peminjaman p : pinjamanList) {
            if (!p.getBarang().isTersedia()) continue; // Skip yang sudah dipinjam
            System.out.println(index++ + ". " + p);
        }

        if (index == 1) {
            System.out.println("Tidak ada permintaan baru.");
            return;
        }

        int pilih = Validator.validateInt(scanner, "Pilih nomor yang disetujui: ");
        if (pilih < 1 || pilih >= index) {
            System.out.println("Pilihan tidak valid.");
            return;
        }

        Peminjaman pinjam = pinjamanList.get(pilih - 1);
        pinjam.getBarang().setTersedia(false);
        System.out.println("Peminjaman disetujui!");
    }

    private void pengembalian() {
        System.out.println("\n=== PENGEMBALIAN BARANG ===");
        if (pinjamanList.isEmpty()) {
            System.out.println("Tidak ada peminjaman.");
            return;
        }

        int index = 1;
        for (Peminjaman p : pinjamanList) {
            System.out.println(index++ + ". " + p);
        }

        int pilih = Validator.validateInt(scanner, "Pilih nomor yang dikembalikan: ");
        if (pilih < 1 || pilih >= index) {
            System.out.println("Pilihan tidak valid.");
            return;
        }

        Peminjaman kembali = pinjamanList.remove(pilih - 1);
        kembali.getBarang().setTersedia(true);

        int tglKembali = Validator.validateInt(scanner, "Tanggal Kembali (1-30): ");
        int lama = tglKembali - kembali.getTanggal();
        int denda = (lama > 3) ? (lama - 3) * 1000 : 0;

        System.out.println("Barang berhasil dikembalikan.");
        if (denda > 0) {
            System.out.println("Terlambat " + (lama - 3) + " hari. Denda: Rp " + denda);
        }
    }

    private void lihatPeminjaman() {
        System.out.println("\n=== DAFTAR PEMINJAMAN ===");
        if (pinjamanList.isEmpty()) {
            System.out.println("Belum ada peminjaman.");
        } else {
            for (Peminjaman p : pinjamanList) {
                System.out.println(p);
            }
        }
    }
}
