package inventori.database;

import inventori.models.*;
import java.io.*;
import java.util.*;

public class PenggunaDB {
    private static final String FILE_NAME = "data/pengguna.txt";

    public static void save(List<Pengguna> penggunaList) {
        try {
            new File("data").mkdirs();
            BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME));
            for (Pengguna p : penggunaList) {
                writer.write(p.getRole() + "," + p.getId() + "," + p.getNama());
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            System.out.println("Gagal menyimpan pengguna: " + e.getMessage());
        }
    }

    public static List<Pengguna> load() {
        List<Pengguna> list = new ArrayList<>();
        try {
            File file = new File(FILE_NAME);
            if (!file.exists()) return list;

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", 3);
                if (parts.length == 3) {
                    String role = parts[0];
                    String id = parts[1];
                    String nama = parts[2];
                    if (role.equals("Admin")) {
                        list.add(new Admin(id, nama));
                    } else {
                        list.add(new Mahasiswa(id, nama));
                    }
                }
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Gagal memuat pengguna: " + e.getMessage());
        }
        return list;
    }
}
