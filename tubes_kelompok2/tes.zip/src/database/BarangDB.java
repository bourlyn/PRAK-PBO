public class BarangDB {
    public static void save(List<Barang> barangList) {
        // Implementasi save ke file
    }
    
    public static List<Barang> load() {
        // Implementasi load dari file
        return new ArrayList<>();
    }
}