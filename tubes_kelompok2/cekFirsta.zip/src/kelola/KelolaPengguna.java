package kelola;

import model.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class KelolaPengguna {
    private List<Pengguna> penggunaList;
    private Scanner scanner;

    public KelolaPengguna() {
        this.scanner = new Scanner(System.in);
        this.penggunaList = new ArrayList<>();
        penggunaList.add(new Admin("1", "1"));
    }

    public void menu() {
        while (true) {
            System.out.println("\n=== KELOLA PENGGUNA ===");
            System.out.println("1. Tambah Pengguna");
            System.out.println("2. Lihat Pengguna");
            System.out.println("3. Edit Pengguna");
            System.out.println("4. Hapus Pengguna");
            System.out.println("0. Kembali");
            System.out.print("Pilih: ");

            String pilihan = scanner.nextLine();
            
            switch (pilihan) {
                case "1" -> tambahPengguna();
                case "2" -> lihatPengguna();
                case "3" -> editPengguna();
                case "4" -> hapusPengguna();
                case "0" -> { return; }
                default -> System.out.println("Pilihan tidak valid!");
            }
        }
    }

    public boolean loginAdmin(String id, String nama) {
        for (Pengguna p : penggunaList) {
            if (p instanceof Admin && p.getId().equals(id) && p.getNama().equals(nama)) {
                return true;
            }
        }
        return false;
    }

    public Pengguna cariPengguna(String id) {
        for (Pengguna p : penggunaList) {
            if (p.getId().equals(id)) {
                return p;
            }
        }
        return null;
    }

    public void lihatPengguna() {
        System.out.println("\n=== DAFTAR PENGGUNA ===");
        for (Pengguna p : penggunaList) {
            // Hanya tampilkan Mahasiswa
            if (p instanceof Mahasiswa) {
                System.out.println(p.getId() + " - " + p.getNama());
            }
        }
    }

    private void tambahPengguna() {
        System.out.println("\n=== TAMBAH PENGGUNA ===");
        System.out.print("Masukkan ID: ");
        String id = scanner.nextLine();
        System.out.print("Masukkan Nama: ");
        String nama = scanner.nextLine();
        
        // Langsung tambahkan sebagai Mahasiswa (tanpa pilihan role)
        penggunaList.add(new Mahasiswa(id, nama));
        System.out.println("Pengguna berhasil ditambahkan!");
    }

    private void editPengguna() {
        System.out.println("\n=== EDIT PENGGUNA ===");
        lihatPengguna();
        System.out.print("Masukkan ID Pengguna yang akan diedit: ");
        String id = scanner.nextLine();
        
        Pengguna pengguna = cariPengguna(id);
        if (pengguna == null) {
            System.out.println("Pengguna tidak ditemukan!");
            return;
        }

        System.out.print("Masukkan Nama Baru: ");
        String namaBaru = scanner.nextLine();
        pengguna.setNama(namaBaru);
        
        System.out.println("Pengguna berhasil diupdate!");
    }

    private void hapusPengguna() {
        System.out.println("\n=== HAPUS PENGGUNA ===");
        lihatPengguna();
        System.out.print("Masukkan ID Pengguna yang akan dihapus: ");
        String id = scanner.nextLine();
        
        Pengguna pengguna = cariPengguna(id);
        if (pengguna == null) {
            System.out.println("Pengguna tidak ditemukan!");
            return;
        }

        if (pengguna instanceof Admin && pengguna.getId().equals("admin")) {
            System.out.println("Admin default tidak bisa dihapus!");
            return;
        }

        penggunaList.remove(pengguna);
        System.out.println("Pengguna berhasil dihapus!");
    }
}