// kelola/KelolaPeminjaman.java
package kelola;

import model.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class KelolaPeminjaman {
    private List<Peminjaman> peminjamanList;
    private KelolaPengguna kelolaPengguna;
    private KelolaBarang kelolaBarang;
    private Scanner scanner;

    public KelolaPeminjaman(KelolaPengguna kelolaPengguna, KelolaBarang kelolaBarang) {
        this.peminjamanList = new ArrayList<>();
        this.kelolaPengguna = kelolaPengguna;
        this.kelolaBarang = kelolaBarang;
        this.scanner = new Scanner(System.in);
    }

    public void menuPeminjaman() {
        while (true) {
            System.out.println("\n=== KELOLA PEMINJAMAN ===");
            System.out.println("1. Request Peminjaman");
            System.out.println("2. Approve Peminjaman");
            System.out.println("3. Pengembalian Barang");
            System.out.println("0. Kembali");
            System.out.print("Pilih: ");

            int pilihan = scanner.nextInt();
            scanner.nextLine(); // Konsumsi newline

            switch (pilihan) {
                case 1 -> requestPeminjaman();
                case 2 -> approvePeminjaman();
                case 3 -> menuPengembalian();
                case 0 -> { return; }
                default -> System.out.println("Pilihan tidak valid!");
            }
        }
    }

    public void menuPengembalian() {
        System.out.println("\n=== PENGEMBALIAN BARANG ===");
        System.out.print("Masukkan ID Barang: ");
        int idBarang = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Tanggal Kembali (1-30): ");
        int tglKembali = scanner.nextInt();
        scanner.nextLine();

        for (Peminjaman p : peminjamanList) {
            if (p.getBarang().getId() == idBarang && p.isDisetujui() && !p.isDikembalikan()) {
                p.hitungDenda(tglKembali);
                p.setDikembalikan(true);

                if (p.getDenda() > 0) {
                    System.out.println("Terlambat! Denda: Rp" + p.getDenda());
                } else {
                    System.out.println("Pengembalian tepat waktu");
                }
                return;
            }
        }
        System.out.println("Data peminjaman tidak ditemukan!");
    }

    private void requestPeminjaman() {
        System.out.println("\n=== REQUEST PEMINJAMAN ===");
        kelolaPengguna.lihatPengguna();
        System.out.print("Masukkan ID Mahasiswa: ");
        String idPeminjam = scanner.nextLine();

        kelolaBarang.lihatBarang();
        System.out.print("Masukkan ID Barang: ");
        int idBarang = scanner.nextInt();
        scanner.nextLine();

        Barang barang = kelolaBarang.cariBarang(idBarang);

        if (barang == null || !barang.isTersedia()) {
            System.out.println("Barang tidak tersedia!");
            return;
        }

        System.out.print("Tanggal Pinjam (1-30): ");
        int tglPinjam = scanner.nextInt();
        scanner.nextLine();

        Peminjaman peminjaman = new Peminjaman(
            kelolaPengguna.cariPengguna(idPeminjam),
            barang,
            tglPinjam
        );
        peminjamanList.add(peminjaman);
        System.out.println("Peminjaman berhasil diajukan!");
        System.out.println("Barang: " + barang.getNama());
        System.out.println("Harap kembalikan sebelum tanggal: " + peminjaman.getTglKembali());
    }

    private void approvePeminjaman() {
        System.out.println("\n=== APPROVE PEMINJAMAN ===");
        System.out.println("Daftar Request Peminjaman (Belum Disetujui):");

        boolean adaRequest = false;
        for (Peminjaman p : peminjamanList) {
            if (!p.isDisetujui()) {
                Barang b = p.getBarang();
                Pengguna u = p.getPeminjam();
                System.out.println("ID Barang: " + b.getId() + ", Nama Barang: " + b.getNama()
                    + " | Peminjam: " + u.getNama());
                adaRequest = true;
            }
        }

        if (!adaRequest) {
            System.out.println("Tidak ada request peminjaman yang menunggu persetujuan.");
            return;
        }

        System.out.print("Masukkan ID Barang untuk disetujui: ");
        int idBarang = scanner.nextInt();
        scanner.nextLine();

        for (Peminjaman p : peminjamanList) {
            if (p.getBarang().getId() == idBarang && !p.isDisetujui()) {
                p.setDisetujui(true);
                System.out.println("Peminjaman untuk barang \"" + p.getBarang().getNama() + "\" disetujui!");
                return;
            }
        }
        System.out.println("Request peminjaman dengan ID barang tersebut tidak ditemukan atau sudah disetujui.");
    }
}
