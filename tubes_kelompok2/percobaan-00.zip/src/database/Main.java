package database;
import kelola.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Inisialisasi semua kelola
        KelolaPengguna kelolaPengguna = new KelolaPengguna();
        KelolaBarang kelolaBarang = new KelolaBarang();
        KelolaPeminjaman kelolaPeminjaman = new KelolaPeminjaman(kelolaPengguna, kelolaBarang);
        KelolaLaporan kelolaLaporan = new KelolaLaporan(kelolaBarang);

        // Login
        System.out.println("=== LOGIN ADMIN ===");
        String nim = Validator.validateString(scanner, "Masukkan NIM Admin: ");
        String nama = Validator.validateString(scanner, "Masukkan Nama Admin: ");
        
        if (!kelolaPengguna.loginAdmin(nim, nama)) {
            System.out.println("Akses ditolak!");
            return;
        }

        // Menu Utama
        while (true) {
            System.out.println("\n=== MENU UTAMA ===");
            System.out.println("1. Kelola Pengguna");
            System.out.println("2. Kelola Barang");
            System.out.println("3. Peminjaman");
            System.out.println("4. Pengembalian");
            System.out.println("5. Laporan");
            System.out.println("0. Keluar");
            System.out.print("Pilih menu: ");

            int menu = Validator.validateInt(scanner);
            
            switch (menu) {
                case 1 -> kelolaPengguna.menu();
                case 2 -> kelolaBarang.menu();
                case 3 -> kelolaPeminjaman.menuPeminjaman();
                case 4 -> kelolaPeminjaman.menuPengembalian();
                case 5 -> kelolaLaporan.menu();
                case 0 -> {
                    System.out.println("Selesai Cihuyy!");
                    return;
                }
                default -> System.out.println("Menu tidak valid!");
            }
        }
    }
}