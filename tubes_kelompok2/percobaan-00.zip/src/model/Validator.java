package model;

import java.util.Scanner;

public class Validator {
    public static int validateInt(Scanner scanner) {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Input harus angka! Coba lagi: ");
            }
        }
    }

    public static int validateInt(Scanner scanner, String prompt) {
        System.out.print(prompt);
        return validateInt(scanner);
    }

    public static int validateTanggal(Scanner scanner, String prompt) {
        while (true) {
            int tgl = validateInt(scanner, prompt);
            if (tgl >= 1 && tgl <= 30) {
                return tgl;
            }
            System.out.println("Tanggal harus antara 1-30!");
        }
    }

    public static String validateString(Scanner scanner, String prompt) {
        String input;
        while (true) {
            System.out.print(prompt);
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                return input;
            }
            System.out.println("Input tidak boleh kosong!");
        }
    }
}