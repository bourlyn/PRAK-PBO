package model;

public class Laporan {
    private Barang barang;
    private String keterangan;
    private String pelapor;

    public Laporan(Barang barang, String keterangan, String pelapor) {
        this.barang = barang;
        this.keterangan = keterangan;
        this.pelapor = pelapor;
    }

    @Override
    public String toString() {
        return "Laporan [Barang: " + barang.getNama() + 
               ", Keterangan: " + keterangan + 
               ", Pelapor: " + pelapor + "]";
    }
}