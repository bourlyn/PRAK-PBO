package kelola;

import model.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class KelolaLaporan {
    private List<Laporan> laporanList;
    private KelolaBarang kelolaBarang;
    private Scanner scanner;

    public KelolaLaporan(KelolaBarang kelolaBarang) {
        this.laporanList = new ArrayList<>();
        this.kelolaBarang = kelolaBarang;
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        while (true) {
            System.out.println("\n=== LAPORAN BARANG ===");
            System.out.println("1. Buat Laporan");
            System.out.println("2. Lihat Laporan");
            System.out.println("0. Kembali");
            System.out.print("Pilih: ");

            int pilihan = Validator.validateInt(scanner);
            
            switch (pilihan) {
                case 1 -> buatLaporan();
                case 2 -> lihatLaporan();
                case 0 -> { return; }
                default -> System.out.println("Pilihan tidak valid!");
            }
        }
    }

    private void buatLaporan() {
        System.out.println("\n=== BUAT LAPORAN ===");
        kelolaBarang.lihatBarang();
        int idBarang = Validator.validateInt(scanner, "Masukkan ID Barang: ");
        Barang barang = kelolaBarang.cariBarang(idBarang);
        
        if (barang == null) {
            System.out.println("Barang tidak ditemukan!");
            return;
        }

        String keterangan = Validator.validateString(scanner, "Keterangan Kerusakan: ");
        String pelapor = Validator.validateString(scanner, "Nama Pelapor: ");
        
        Laporan laporan = new Laporan(barang, keterangan, pelapor);
        laporanList.add(laporan);
        barang.setTersedia(false);
        System.out.println("Laporan berhasil dibuat:\n" + laporan);
    }

    private void lihatLaporan() {
        System.out.println("\n=== DAFTAR LAPORAN ===");
        for (Laporan l : laporanList) {
            System.out.println(l);
        }
    }
}