package kelola;

import model.*;
import database.BarangDB;
import java.util.List;
import java.util.Scanner;

public class KelolaBarang {
    private List<Barang> barangList;
    private Scanner scanner;

    public KelolaBarang() {
        this.scanner = new Scanner(System.in);
        this.barangList = BarangDB.load();
    }

    public void menu() {
        while (true) {
            System.out.println("\n=== KELOLA BARANG ===");
            System.out.println("1. Tambah Barang");
            System.out.println("2. Lihat Barang");
            System.out.println("3. Edit Barang");
            System.out.println("4. Hapus Barang");
            System.out.println("0. Kembali");
            System.out.print("Pilih: ");

            int pilihan = Validator.validateInt(scanner);
            
            switch (pilihan) {
                case 1 -> tambahBarang();
                case 2 -> lihatBarang();
                case 3 -> editBarang();
                case 4 -> hapusBarang();
                case 0 -> { return; }
                default -> System.out.println("Pilihan tidak valid!");
            }
        }
    }

    private void tambahBarang() {
        System.out.println("\n=== TAMBAH BARANG ===");
        int id = Validator.validateInt(scanner, "Masukkan ID Barang: ");
        String nama = Validator.validateString(scanner, "Masukkan Nama Barang: ");
        
        barangList.add(new Barang(id, nama));
        BarangDB.save(barangList);
        System.out.println("Barang berhasil ditambahkan!");
    }

    public Barang cariBarang(int id) {
        for (Barang b : barangList) {
            if (b.getId() == id) {
                return b;
            }
        }
        return null;
    }

    public void lihatBarang() {
        System.out.println("\n=== DAFTAR BARANG ===");
        System.out.println("ID\tNama\tStatus");
        System.out.println("-----------------------");
        for (Barang b : barangList) {
            System.out.println(b.getId() + "\t" + b.getNama() + "\t" + 
                (b.isTersedia() ? "Tersedia" : "Dipinjam"));
        }
    }

    private void editBarang() {
        System.out.println("\n=== EDIT BARANG ===");
        lihatBarang();
        int id = Validator.validateInt(scanner, "Masukkan ID Barang yang akan diedit: ");
        
        Barang barang = cariBarang(id);
        if (barang == null) {
            System.out.println("Barang tidak ditemukan!");
            return;
        }

        System.out.println("Data saat ini:");
        System.out.println(barang);

        String namaBaru = Validator.validateString(scanner, "Masukkan Nama Baru (kosongkan jika tidak ingin mengubah): ");
        if (!namaBaru.isEmpty()) {
            barang.setNama(namaBaru);
        }

        String status = Validator.validateString(scanner, "Ubah status tersedia? (y/t): ");
        if (status.equalsIgnoreCase("y")) {
            barang.setTersedia(!barang.isTersedia());
        }

        BarangDB.save(barangList);
        System.out.println("Barang berhasil diupdate!");
    }

    private void hapusBarang() {
        System.out.println("\n=== HAPUS BARANG ===");
        lihatBarang();
        int id = Validator.validateInt(scanner, "Masukkan ID Barang yang akan dihapus: ");
        
        Barang barang = cariBarang(id);
        if (barang == null) {
            System.out.println("Barang tidak ditemukan!");
            return;
        }

        // Cek apakah barang sedang dipinjam
        if (!barang.isTersedia()) {
            System.out.println("Barang sedang dipinjam, tidak bisa dihapus!");
            return;
        }

        System.out.println("Anda akan menghapus:");
        System.out.println(barang);
        String konfirmasi = Validator.validateString(scanner, "Apakah Anda yakin? (y/t): ");
        
        if (konfirmasi.equalsIgnoreCase("y")) {
            barangList.remove(barang);
            BarangDB.save(barangList);
            System.out.println("Barang berhasil dihapus!");
        } else {
            System.out.println("Penghapusan dibatalkan");
        }
    }
}