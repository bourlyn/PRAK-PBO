package kelola;

import model.*;
import database.PenggunaDB;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class KelolaPengguna {
    private List<Pengguna> penggunaList;
    private Scanner scanner;

    public KelolaPengguna() {
        this.scanner = new Scanner(System.in);
        this.penggunaList = PenggunaDB.load();
        
        // Tambah admin default jika tidak ada
        if (penggunaList.isEmpty()) {
            penggunaList.add(new Admin("admin", "Administrator"));
            PenggunaDB.save(penggunaList);
        }
    }

    public void menu() {
        while (true) {
            System.out.println("\n=== KELOLA PENGGUNA ===");
            System.out.println("1. Tambah Pengguna");
            System.out.println("2. Lihat Pengguna");
            System.out.println("3. Edit Pengguna");
            System.out.println("4. Hapus Pengguna");
            System.out.println("0. Kembali");
            System.out.print("Pilih: ");

            int pilihan = Validator.validateInt(scanner);
            
            switch (pilihan) {
                case 1 -> tambahPengguna();
                case 2 -> lihatPengguna();
                case 3 -> editPengguna();
                case 4 -> hapusPengguna();
                case 0 -> { return; }
                default -> System.out.println("Pilihan tidak valid!");
            }
        }
    }

    public boolean loginAdmin(String id, String nama) {
        for (Pengguna p : penggunaList) {
            if (p instanceof Admin && p.getId().equals(id) && p.getNama().equals(nama)) {
                return true;
            }
        }
        return false;
    }

    private void tambahPengguna() {
        System.out.println("\n=== TAMBAH PENGGUNA ===");
        String id = Validator.validateString(scanner, "Masukkan ID: ");
        String nama = Validator.validateString(scanner, "Masukkan Nama: ");
        
        System.out.print("Role (1. Admin, 2. Mahasiswa): ");
        int role = Validator.validateInt(scanner);
        
        if (role == 1) {
            penggunaList.add(new Admin(id, nama));
        } else if (role == 2) {
            penggunaList.add(new Mahasiswa(id, nama));
        } else {
            System.out.println("Role tidak valid!");
            return;
        }
        
        PenggunaDB.save(penggunaList);
        System.out.println("Pengguna berhasil ditambahkan!");
    }

    // Method lainnya (lihatPengguna, editPengguna, hapusPengguna)...
}