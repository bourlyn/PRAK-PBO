package kelola;

import model.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class KelolaPeminjaman {
    private List<Peminjaman> peminjamanList;
    private KelolaPengguna kelolaPengguna;
    private KelolaBarang kelolaBarang;
    private Scanner scanner;

    public KelolaPeminjaman(KelolaPengguna kelolaPengguna, KelolaBarang kelolaBarang) {
        this.peminjamanList = new ArrayList<>();
        this.kelolaPengguna = kelolaPengguna;
        this.kelolaBarang = kelolaBarang;
        this.scanner = new Scanner(System.in);
    }

    public void menuPeminjaman() {
        while (true) {
            System.out.println("\n=== KELOLA PEMINJAMAN ===");
            System.out.println("1. Request Peminjaman");
            System.out.println("2. Approve Peminjaman");
            System.out.println("0. Kembali");
            System.out.print("Pilih: ");

            int pilihan = Validator.validateInt(scanner);
            
            switch (pilihan) {
                case 1 -> requestPeminjaman();
                case 2 -> approvePeminjaman();
                case 0 -> { return; }
                default -> System.out.println("Pilihan tidak valid!");
            }
        }
    }

    public void menuPengembalian() {
        System.out.println("\n=== PENGEMBALIAN BARANG ===");
        int idBarang = Validator.validateInt(scanner, "Masukkan ID Barang: ");
        int tglKembali = Validator.validateTanggal(scanner, "Tanggal Kembali (1-30): ");

        for (Peminjaman p : peminjamanList) {
            if (p.getBarang().getId() == idBarang && p.isDisetujui() && !p.isDikembalikan()) {
                p.hitungDenda(tglKembali);
                p.setDikembalikan(true);
                
                if (p.getDenda() > 0) {
                    System.out.println("Terlambat! Denda: Rp" + p.getDenda());
                } else {
                    System.out.println("Pengembalian tepat waktu");
                }
                return;
            }
        }
        System.out.println("Data peminjaman tidak ditemukan!");
    }

    private void requestPeminjaman() {
        System.out.println("\n=== REQUEST PEMINJAMAN ===");
        
        // Validasi mahasiswa
        System.out.println("Daftar Mahasiswa:");
        kelolaPengguna.lihatPengguna();
        String idPeminjam = Validator.validateString(scanner, "Masukkan ID Mahasiswa: ");
        
        // Validasi barang tersedia
        kelolaBarang.lihatBarang();
        int idBarang = Validator.validateInt(scanner, "Masukkan ID Barang: ");
        Barang barang = kelolaBarang.cariBarang(idBarang);
        
        if (barang == null || !barang.isTersedia()) {
            System.out.println("Barang tidak tersedia!");
            return;
        }

        // Validasi tanggal
        int tglPinjam = Validator.validateTanggal(scanner, "Tanggal Pinjam (1-30): ");
        
        // Buat peminjaman
        Peminjaman peminjaman = new Peminjaman(
            kelolaPengguna.cariPengguna(idPeminjam), 
            barang, 
            tglPinjam
        );
        peminjamanList.add(peminjaman);
        System.out.println("Peminjaman berhasil diajukan!");
        System.out.println("Harap kembalikan sebelum tanggal: " + peminjaman.getTglKembali());
    }

    private void approvePeminjaman() {
        System.out.println("\n=== APPROVE PEMINJAMAN ===");
        System.out.println("Daftar Request Peminjaman:");
        System.out.println("No\tPeminjam\tBarang");
        System.out.println("-------------------------------");
        
        for (int i = 0; i < peminjamanList.size(); i++) {
            Peminjaman p = peminjamanList.get(i);
            if (!p.isDisetujui()) {
                System.out.println(i + ".\t" + p.getPeminjam().getNama() + 
                                 "\t\t" + p.getBarang().getNama());
            }
        }

        int index = Validator.validateInt(scanner, "Pilih nomor request: ");
        if (index >= 0 && index < peminjamanList.size()) {
            Peminjaman p = peminjamanList.get(index);
            p.setDisetujui(true);
            System.out.println("Peminjaman disetujui!");
        } else {
            System.out.println("Nomor tidak valid!");
        }
    }
}