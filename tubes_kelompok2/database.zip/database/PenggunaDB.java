package database;

import model.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PenggunaDB {
    private static final String FILE_NAME = "data/pengguna.txt";

    public static void save(List<Pengguna> penggunaList) {
        try {
            new File("data").mkdirs();
            BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME));
            
            for (Pengguna p : penggunaList) {
                String role = p instanceof Admin ? "Admin" : "Mahasiswa";
                writer.write(p.getId() + "," + p.getNama() + "," + role);
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            System.out.println("Gagal menyimpan data pengguna: " + e.getMessage());
        }
    }

    public static List<Pengguna> load() {
        List<Pengguna> penggunaList = new ArrayList<>();
        try {
            File file = new File(FILE_NAME);
            if (!file.exists()) return penggunaList;
            
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    String id = parts[0];
                    String nama = parts[1];
                    String role = parts[2];
                    
                    if (role.equals("Admin")) {
                        penggunaList.add(new Admin(id, nama));
                    } else {
                        penggunaList.add(new Mahasiswa(id, nama));
                    }
                }
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Gagal memuat data pengguna: " + e.getMessage());
        }
        return penggunaList;
    }
}