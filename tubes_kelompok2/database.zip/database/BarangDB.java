package database;

import model.Barang;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class BarangDB {
    private static final String FILE_NAME = "data/barang.txt";

    public static void save(List<Barang> barangList) {
        try {
            new File("data").mkdirs();
            BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME));
            
            for (Barang barang : barangList) {
                writer.write(barang.getId() + "," + barang.getNama() + "," + barang.isTersedia());
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            System.out.println("Gagal menyimpan data barang: " + e.getMessage());
        }
    }

    public static List<Barang> load() {
        List<Barang> barangList = new ArrayList<>();
        try {
            File file = new File(FILE_NAME);
            if (!file.exists()) return barangList;
            
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    Barang barang = new Barang(Integer.parseInt(parts[0]), parts[1]);
                    barang.setTersedia(Boolean.parseBoolean(parts[2]));
                    barangList.add(barang);
                }
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Gagal memuat data barang: " + e.getMessage());
        }
        return barangList;
    }
}