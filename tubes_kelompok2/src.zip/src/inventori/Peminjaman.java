package inventori;

public class Peminjaman {
    private String nimPeminjam;
    private int idBarang;
    private boolean disetujui;
    private int tanggalPinjam;

    public Peminjaman(String nimPeminjam, int idBarang, int tanggalPinjam) {
        this.nimPeminjam = nimPeminjam;
        this.idBarang = idBarang;
        this.tanggalPinjam = tanggalPinjam;
        this.disetujui = false;
    }

    public String getNimPeminjam() {
        return nimPeminjam;
    }

    public int getIdBarang() {
        return idBarang;
    }

    public boolean isDisetujui() {
        return disetujui;
    }

    public void setDisetujui(boolean disetujui) {
        this.disetujui = disetujui;
    }

    public int getTanggalPinjam() {
        return tanggalPinjam;
    }
}