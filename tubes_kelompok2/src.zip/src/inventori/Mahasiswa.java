package inventori;

public class Mahasiswa extends Pengguna {
    public Mahasiswa(String nim, String nama) {
        super(nim, nama);
    }

    public String getRole() {
        return "Mahasiswa";
    }
}